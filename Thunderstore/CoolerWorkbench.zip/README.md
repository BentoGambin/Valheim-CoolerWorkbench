# Cooler Workbench

At it's core this is a simple alternative to the early-game looking workbench. For some, it's just a pretty remodel, but, for those of us who can't stand a second longer looking at that ugly and messy comglomerate of planks and stones that some call a workbench, it is salvation.

![](https://i.imgur.com/GQr8Lrt.png)

No longer will the trusty workbench (that got you where your caracter is [but come on, who cares]) stain the beauty of your base.

Also gives +1 confort.

Also has 50% larger build area.

Also works without a roof.

Also is more durable.

No, I won't upload to nexus, sorry.

## My bucket List for this mod
* Use the game's own sound files, therefore reducing file size.
* Possibly add variants, therefore increasing file size again.
* Make crafting faster when using the cooler of the workbenches.

## Thanks
    Models and textures: Bento (me).
    Code base: Azumatt.
    (massive) code help: Grave Bear and Advize iͣzͩeͮ.
## Changelog

* 1.1.0 -> Major re-texure. Also Lower texture size on LOD.
* 1.0.1 -> Thunderstore Description Fix.
* 1.0.0 -> Thunderstore Upload.

## Contact

* https://discord.gg/Pb6bVMnFb2
    * @Bento#5066
